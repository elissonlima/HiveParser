HiveParser Module

We try to parse a Hive QL script to a JSON structure.

Usage:
	import hiveparser

	hiveparser.parse("SELECT * FROM tab;")

See the magic begins.

Elisson Lima Gomes da Silva